$CodeBlock=@'
insert enc64 content here
'@

