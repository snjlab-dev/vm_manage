#.\sworm_deply_async_twoNIC.ps1 -from vm -csv .\deploy_oper.csv -afterProc:True


Param(
    [Parameter(HelpMessage="fuckyou")]
    [switch]$Force,
    
    [Parameter(Mandatory,
    HelpMessage="이미지를 어디서 부터 복사하는지 (template/vm")]
    [ValidateSet("template", "vm")]
    [string]
    $from,

    [Parameter(Mandatory,
    HelpMessage="어떤리스트를 불러올 것인지")]
    [string]
    $csv,

    [Parameter(Mandatory,HelpMessage="vm생성후 후처리를 할 것인지")]
    [switch]$afterProc

)

$csvString = $csv
#echo $csvString
$list = Import-Csv $csvString

Write-Output $afterProc
Write-Output $csv
Write-Output '(template/vm):'$from
Write-Output 'after proc' $afterProc

if($afterProc){
    foreach($col in $list) {
        $name = $col.vmname
        $ip1 = $col.ip1
        $ds = $col.datastore
        $template = $col.template
        $esxi = $col.esxi
        $pg = $col.pg
        $gw = $col.gw
        $cpu = $col.cpu
        $mem = $col.mem
        $secondpg = $col.secondpg
        $asdf = $col.asdf

        Write-Output $name 
        Write-Output $ip1 
        Write-Output $ds 
        Write-Output $esxi 
        Write-Output $secondpg 
        Write-Output $asdf


        if($secondpg){
            Write-Output "secondpg"
        }
    }

}else{
    return
    break
}




